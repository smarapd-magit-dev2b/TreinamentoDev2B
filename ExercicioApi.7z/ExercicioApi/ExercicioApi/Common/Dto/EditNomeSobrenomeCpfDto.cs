﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common.Dto
{
    public class EditNomeSobrenomeCpfDto
    {
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public string Cpf { get; set; }
    }
}
